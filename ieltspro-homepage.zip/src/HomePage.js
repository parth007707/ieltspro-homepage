import React from "react";

const HomePage = () => {
  return (
    <div className="font-sans">
      {/* Navbar */}
      <nav className="flex justify-between items-center p-4 shadow-md bg-white">
        <h1 className="text-2xl font-bold text-blue-600">IELTSPro</h1>
        <ul className="flex space-x-6">
          <li><a href="#features" className="hover:text-blue-600">Features</a></li>
          <li><a href="#testimonials" className="hover:text-blue-600">Testimonials</a></li>
          <li><a href="#contact" className="hover:text-blue-600">Contact</a></li>
        </ul>
      </nav>

      {/* Hero Section */}
      <section className="text-center py-16 bg-blue-50">
        <h2 className="text-4xl font-bold mb-4">Achieve Your Dream IELTS Score</h2>
        <p className="text-lg text-gray-700 mb-6">Join IELTSPro for expert guidance, AI-driven feedback, and guaranteed improvement.</p>
        <button className="px-6 py-3 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">Get Started</button>
      </section>

      {/* Features */}
      <section id="features" className="py-16 px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          {title: "Speaking Practice", desc: "Interactive sessions with AI & trainers."},
          {title: "Mock Tests", desc: "Simulated real-exam conditions."},
          {title: "AI Band Score", desc: "Instant AI-powered scoring & feedback."},
          {title: "Personalized Study Plan", desc: "Track your progress & improve faster."}
        ].map((f, i) => (
          <div key={i} className="p-6 border rounded-xl shadow hover:shadow-lg transition">
            <h3 className="text-xl font-semibold mb-2">{f.title}</h3>
            <p className="text-gray-600">{f.desc}</p>
          </div>
        ))}
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-16 bg-gray-100 text-center">
        <h2 className="text-3xl font-bold mb-6">What Our Students Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {[
            {name: "Amit Sharma", text: "IELTSPro helped me score Band 8 in just 2 months!"},
            {name: "Sarah Khan", text: "The AI feedback was a game changer for my preparation."}
          ].map((t, i) => (
            <div key={i} className="p-6 bg-white rounded-xl shadow">
              <p className="text-gray-700 italic">"{t.text}"</p>
              <h4 className="mt-4 font-semibold">{t.name}</h4>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="py-6 bg-blue-600 text-white text-center">
        <p>© 2025 IELTSPro Institute. All rights reserved.</p>
        <p>Email: info@ieltspro.com | Phone: +91 98765 43210</p>
      </footer>
    </div>
  );
};

export default HomePage;
