# IELTSPro Home Page

A modern, responsive homepage for a fictional IELTS Institute built with React and Tailwind CSS.

## 🚀 Features
- Navbar with logo & links
- Hero section with headline, text, button
- 4 Feature cards
- Student testimonials
- Footer with contact info
- Fully responsive design

## 🛠 Setup Instructions
1. Clone the repository or unzip the folder
2. Run `npm install`
3. Start development server with `npm start`

## 🎨 Design Choices
- **Tailwind CSS**: for quick, clean, responsive UI
- **Component-based structure**: easy to maintain and scale
- **Modern look**: flat design, soft shadows, rounded corners

---
© 2025 IELTSPro Institute (fictional project for internship)
